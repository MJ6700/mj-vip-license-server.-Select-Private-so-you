#!/system/bin/sh
# Intentionally no background service. Add only your own module's startup tasks here.
exit 0
