#!/system/bin/sh
ui_print "*******************************"
ui_print " MJ VIP/PRO License Starter"
ui_print "*******************************"
ui_print "This is a starter template."
ui_print "Configure your own HTTPS license API before production use."
ui_print "It does not activate or modify COPG."
