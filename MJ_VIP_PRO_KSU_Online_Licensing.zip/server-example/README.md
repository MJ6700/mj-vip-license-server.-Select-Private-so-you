# MJ VIP/PRO online license API

This reference API issues lifetime keys for **your own MJ VIP/PRO features only**. It does not create or validate COPG licenses.

## Requirements
- Node.js 18+
- A server/VPS or Node-compatible hosting
- HTTPS in production (put this behind a TLS reverse proxy or use a host that provides HTTPS)

## 1. Start it locally

Linux/macOS:
```sh
cd server-example
export MJ_ADMIN_TOKEN="$(openssl rand -hex 32)"
export PORT=8787
npm start
```

Windows PowerShell:
```powershell
cd server-example
$env:MJ_ADMIN_TOKEN = [Convert]::ToHexString([Security.Cryptography.RandomNumberGenerator]::GetBytes(32))
$env:PORT = "8787"
npm start
```

Keep `MJ_ADMIN_TOKEN` secret. Never put it in `webroot/config.js`, the module ZIP, screenshots, or a public repository. The first run creates `licenses.json` beside `server.js`; protect it and back it up securely. Do not use a temporary filesystem in production.

Health check:
```sh
curl https://YOUR-HOST.example/api/health
```

## 2. Issue lifetime licenses

Only run this from a trusted admin machine. Replace the URL and token:
```sh
curl -X POST "https://YOUR-HOST.example/api/admin/licenses" \
  -H "Authorization: Bearer $MJ_ADMIN_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"count":1,"note":"test/customer order reference"}'
```
The response shows the generated `MJPRO-...` key once. Save it securely; the server stores only a SHA-256 hash. `count` can be 1–25. Licenses are lifetime (`expiresAt: null`) but can be revoked by the administrator.

## 3. Configure the module

Edit `webroot/config.js`:
```js
window.MJ_LICENSE_CONFIG = {
  productName: "MJ VIP/PRO",
  apiBaseUrl: "https://YOUR-HOST.example/api",
  previewMode: false
};
```
Repackage the module ZIP with `module.prop` at the archive root, install it as its own module in KernelSU Next, then open its WebUI. Enter a key and tap **Verify / Activate**. On first successful activation, the license is permanently bound to that installation's locally stored random device ID. This is a convenience binding, not hardware-backed proof; clearing WebView/local storage may change the ID.

## 4. Revoke a license

```sh
curl -X POST "https://YOUR-HOST.example/api/admin/revoke" \
  -H "Authorization: Bearer $MJ_ADMIN_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"licenseKey":"MJPRO-PASTE-KEY-HERE"}'
```
Revocation takes effect on the next online verification. The sample client fails closed if the API cannot be reached, so it does not grant PRO while offline.

## Production hardening checklist
- Use HTTPS only; don't expose port 8787 directly to the internet.
- Use a long random admin token stored in hosting secrets, not in source code.
- Put the API behind a TLS reverse proxy/managed host; enable request size limits, rate limits, logs, and monitoring at the edge.
- Persist and back up `licenses.json`; for multiple server instances, replace the JSON file with a transactional database (e.g. PostgreSQL).
- Add account/admin authentication and payment/order reconciliation before selling keys.
- Do not claim this is tamper-proof: rooted clients can patch local UI checks. Put valuable services/actions behind server-side authorization.
- The current API is a small reference implementation; review and security-test it before production use.

## API behavior
- `GET /api/health`
- `POST /api/activate` with `{ "product":"MJ VIP/PRO", "licenseKey":"...", "deviceId":"..." }`
- `POST /api/admin/licenses` (admin bearer token) with `{ "count":1, "note":"optional" }`
- `POST /api/admin/revoke` (admin bearer token) with `{ "licenseKey":"..." }`

COPG's existing license verification remains separate and untouched. Do not use this service to imitate, replace, or bypass third-party licensing.
