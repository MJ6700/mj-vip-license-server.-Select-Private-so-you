#!/system/bin/sh
ui_print "MJ VIP/PRO starter removed. No COPG files were changed."
