# MJ VIP/PRO KernelSU Next module (starter + online license API)

This is a separate starter module for features you own. It does not modify COPG, issue COPG licenses, or unlock COPG-owned PRO features.

## Install / test
1. Ensure the ZIP has `module.prop` at its root.
2. Install the ZIP as a separate module from KernelSU Next's module page.
3. Open `webroot/index.html` if your KernelSU Next build supports module WebUI.
4. The UI starts fail-closed; PRO remains locked until your own API validates a key.

## Configure online lifetime licensing
See [`server-example/README.md`](server-example/README.md) for Node.js setup, secure admin token configuration, key issuance, device binding, and revocation.

Before use, edit `webroot/config.js` to set your HTTPS API base URL and `previewMode: false`. Never place the admin token or other server secrets in the ZIP.

## Security notes
- Lifetime means no automatic expiration; an administrator can still revoke a license.
- Device binding uses a locally stored random ID and is not hardware-backed. Clearing local storage may change it.
- The sample client fails closed when verification fails. Rooted devices can patch client-side UI checks, so protect valuable server-side operations with server-side authorization.
- The included Node server is a reference implementation, not a substitute for production security review. Use HTTPS, a persistent database, backups, edge rate limits, and secure secret storage.

## Preserve COPG
Keep this as its own module (`id=mj_vip_pro`). Do not overwrite COPG files, alter its license code, or use this project to bypass its checks.
