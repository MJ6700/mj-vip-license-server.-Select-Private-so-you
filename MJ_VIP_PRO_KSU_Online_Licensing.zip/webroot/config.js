/* Configure this for YOUR license service. Never put admin tokens or private secrets here. */
window.MJ_LICENSE_CONFIG = {
  productName: "MJ VIP/PRO",
  apiBaseUrl: "https://YOUR-LICENSE-SERVER.example/api",
  // Keep true until the HTTPS API is deployed and tested. Preview mode never grants PRO.
  previewMode: true
};
