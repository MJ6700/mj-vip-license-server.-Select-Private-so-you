(() => {
  const cfg = window.MJ_LICENSE_CONFIG || {};
  const $ = id => document.getElementById(id);
  const deviceId = async () => {
    // Stable local identifier for this WebUI installation; not hardware proof.
    let id = localStorage.getItem('mjpro_device_id');
    if (!id) {
      const bytes = crypto.getRandomValues(new Uint8Array(16));
      id = Array.from(bytes, b => b.toString(16).padStart(2,'0')).join('');
      localStorage.setItem('mjpro_device_id', id);
    }
    return id;
  };
  const setStatus = (text, detail, ok=false) => {
    $('statusText').textContent = text;
    $('detail').textContent = detail;
    $('status').className = 'status ' + (ok ? 'ok' : 'bad');
  };
  const showLocked = msg => {
    setStatus('PRO locked', msg, false);
    $('message').textContent = 'No PRO access has been granted.';
    window.MJ_PRO_ENABLED = false;
  };
  deviceId().then(id => $('device').value = id);
  async function verify() {
    const key = $('license').value.trim();
    if (!key) return showLocked('Enter your own license key first.');
    if (cfg.previewMode || !cfg.apiBaseUrl || cfg.apiBaseUrl.includes('YOUR-LICENSE-SERVER')) {
      return showLocked('Preview mode is enabled. Configure your own HTTPS API to perform real verification.');
    }
    try {
      const res = await fetch(cfg.apiBaseUrl.replace(/\/$/,'') + '/activate', {
        method:'POST', headers:{'Content-Type':'application/json'},
        body:JSON.stringify({product:cfg.productName || 'MJ VIP/PRO', licenseKey:key, deviceId:$('device').value})
      });
      if (!res.ok) throw new Error('Server returned HTTP ' + res.status);
      const data = await res.json();
      // The API must return an explicit successful entitlement. Never infer PRO from HTTP 200 alone.
      if (data.valid === true && data.product === (cfg.productName || 'MJ VIP/PRO') && data.pro === true) {
        setStatus('PRO verified', data.expiresAt ? 'License valid until ' + data.expiresAt : 'License verified by your server.', true);
        $('message').textContent = 'Server verification succeeded.';
        window.MJ_PRO_ENABLED = true;
      } else showLocked(data.message || 'License not entitled to PRO for this device.');
    } catch (e) { showLocked('Could not verify: ' + e.message + '. Check HTTPS endpoint and network, then retry.'); }
  }
  $('activate').addEventListener('click', verify);
  $('refresh').addEventListener('click', verify);
  window.MJ_LICENSE = { verify, hasPro: () => window.MJ_PRO_ENABLED === true };
  showLocked('Not activated. Configure your own licensing API before use.');
})();
